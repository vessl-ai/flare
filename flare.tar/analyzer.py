"""
Analyzers that analyzes the data from collectors and make diagnoses.
"""

from classes.analyzer import AnalyzerSummary
from classes.collector import CollectorSummary
from classes.option import FlareOptions


def analyze_all(collector_summary: CollectorSummary, options: FlareOptions) -> AnalyzerSummary:
    summary = AnalyzerSummary()

    return summary
