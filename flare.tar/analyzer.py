"""
Analyzers that analyzes the data from collectors and make diagnoses.
"""

import re
import string
from io import StringIO
from typing import Dict, List, Tuple, Type

from classes.analyzer import AbstractAnalyzer, AnalyzerSummary
from classes.collector import CollectorSummary
from classes.option import FlareOptions


class NVIDIADriverAnalyzer(AbstractAnalyzer):
    """
    Analyzer that checks NVIDIA driver installation status.
    """

    @classmethod
    def _find_loaded_module_version(cls, summary: CollectorSummary) -> str:
        """
        From /sys/module/nvidia/version, returns version strings like "535.154.05", or "" if not found.
        """
        if summary.nvidia is None:
            return ""
        version = summary.nvidia.content_kernel_driver_version_nvidia
        if version is None:
            return ""

        version = version.strip()
        if re.match(r"^[0-9.]+$", version) is None:
            return ""

        return version

    @classmethod
    def _find_dpkg_driver_versions(cls, summary: CollectorSummary) -> List[str]:
        """
        From `dpkg -l`, finds nvidia-driver-* package versions.
        Note:
        - Package versions have the pattern '525.147.05-0ubuntu0.20.04.1'. Parse the '525.147.05' part only.
        - Older packages can migrate to transitional version.
          For example, both nvidia-driver-515 and *-525 package can be installed,
          and they will both have version 525.147.05-* in that case.
          Thus, use set() to deduplicate versions.
        """

        if summary.package is None:
            return []

        if summary.package.output_dpkg_l is None:
            return []

        versions = set()

        for line in summary.package.output_dpkg_l.strip().split("\n"):
            m = re.match(r"^[a-z][A-Za-z][ R]\s*(?P<package_name>[^\s]+)\s+(?P<version>[0-9.]+)", line)
            if m is None:
                continue

            package_name, version = m.group("package_name"), m.group("version")
            if package_name.startswith("nvidia-driver-"):
                versions.add(version)

        return sorted(list(versions))

    @classmethod
    def _find_kernels_with_nvidia(cls, summary: CollectorSummary) -> List[str]:
        """
        Find kernel versions (e.g. "5.4.0-123-generic") that has `nvidia.ko`.
        """
        if summary.nvidia is None or summary.nvidia.output_kernels_with_nvidia is None:
            return []

        kernels_with_nvidia_raw = summary.nvidia.output_kernels_with_nvidia
        kernel_versions: List[str] = re.findall(r"/lib/modules/([^/]+)/[^\s]*/nvidia\.ko", kernels_with_nvidia_raw)

        kernel_versions = list(set(kernel_versions))
        # Since we do "ls /lib/modules/*/kernel/drivers/video/nvidia.ko", the error message
        # (when no such files exist) can contain this exact line. Filter '*' out.
        kernel_versions = list(filter(lambda x: x != "*", kernel_versions))

        return kernel_versions

    @classmethod
    def analyze(cls, collector_summary: CollectorSummary, options: FlareOptions) -> str:
        buffer = StringIO()

        def _say(*args, **kwargs):
            print(*args, **kwargs, file=buffer)

        loaded_module_version = cls._find_loaded_module_version(summary=collector_summary)
        _say(f"Kernel module version: {loaded_module_version or '(not found)'}")
        _say()

        _say("Package manager driver versions (can be empty when installed with .run):")
        dpkg_versions = cls._find_dpkg_driver_versions(summary=collector_summary)
        _say(f"- dpkg (apt): [{', '.join(dpkg_versions)}]")
        _say()

        def _check_package_manager_driver_versions():
            if len(dpkg_versions) > 1:
                _say("##### Too many driver versions!")
                _say(f"dpkg (apt) show these driver versions: [{', '.join(dpkg_versions)}]")
                _say("Consider deleting older drivers.")
                _say()

            if len(dpkg_versions) > 0 and loaded_module_version != "" and loaded_module_version not in dpkg_versions:
                _say("##### Driver version mismatch!")
                _say(f"dpkg (apt) show these driver versions: [{', '.join(dpkg_versions)}]")
                _say(f"However, current kernel version is {loaded_module_version}.")
                _say()
                _say("This is possible when driver was auto-updated, but system has not rebooted.")
                _say("Consider rebooting the system.")
                _say()

        _check_package_manager_driver_versions()

        def _check_dkms():
            if collector_summary.system is None or collector_summary.system.output_uname_a is None:
                _say("Cannot parse kernel version; ignoring DKMS check.")
                return

            uname_split = collector_summary.system.output_uname_a.split()
            if len(uname_split) < 3:
                _say("Cannot parse kernel version; ignoring DKMS check.")
                return

            current_kernel = uname_split[2]
            kernels_with_nvidia = cls._find_kernels_with_nvidia(collector_summary)
            if (
                loaded_module_version == ""
                and len(kernels_with_nvidia) != 0
                and current_kernel not in kernels_with_nvidia
            ):
                _say("##### Possible DKMS problem detected!")
                _say()
                _say(f"NVIDIA driver exists for kernel versions: {', '.join(kernels_with_nvidia)}")
                _say(f"However, your current kernel version is {current_kernel}.")
                _say()
                _say("This is possible when:")
                _say("* NVIDIA driver was installed without DKMS support.")
                _say("* Then, Linux kernel was updated (via auto-update, for example).")
                _say("* Then, system was rebooted.")
                _say()
                _say("Consider installing DKMS and running `dkms install nvidia/xxx.xxx.xx`.")
                _say()

        _check_dkms()

        return buffer.getvalue()


class NVIDIAGPUCheckAnalyzer(AbstractAnalyzer):
    @classmethod
    def analyze(cls, collector_summary: CollectorSummary, options: FlareOptions) -> str:
        buffer = StringIO()

        def _say(*args, **kwargs):
            print(*args, **kwargs, file=buffer)

        def _check_nvidia_smi_output():
            try:  # type assertion
                assert collector_summary.nvidia is not None
                assert collector_summary.nvidia.output_smi_q is not None
            except AssertionError:
                _say("`nvidia-smi -q` output not found.")
                return

            smi_q_output = collector_summary.nvidia.output_smi_q
            if "===NVSMI LOG===" not in smi_q_output:
                _say("##### `nvidia-smi -q` failed!")
                _say()
                _say("Output of `nvidia-smi -q` does not seem normal.")
                _say("There might be a problem with GPU devices.")
                _say()

        _check_nvidia_smi_output()

        def _check_dmesg_xid():
            try:  # type assertion
                assert collector_summary.system is not None
                assert collector_summary.system.output_dmesg is not None
            except AssertionError:
                _say("`dmesg` output not found.")
                return
            dmesg_output = collector_summary.system.output_dmesg
            dmesg_nvrm = list(filter(lambda line: "NVRM" in line, dmesg_output.split("\n")))
            bad_lines = list(filter(lambda line: "Xid" in line or "fallen off the bus" in line, dmesg_nvrm))

            if len(bad_lines) > 0:
                _say("##### GPU issue in kernel log!")
                _say()
                _say("Flare has found these lines in dmesg output:")
                for i, line in enumerate(bad_lines):
                    if i >= 10:
                        _say("    ", f"({len(bad_lines)-10} more line(s))")
                        break
                    _say("    ", line)
                _say()
                _say("These may indicate a GPU hardware fault, in which case a reboot is required.")
                _say()

        _check_dmesg_xid()

        return buffer.getvalue()


class K0sConfigAnalyzer(AbstractAnalyzer):
    @staticmethod
    def _get_k0s_runtime(summary: CollectorSummary) -> str:
        """
        Find CRI that k0s uses.
        It defaults to containerd, but in old setups (k8s <= 1.23), Docker is also possible.
        If unknown, return "".
        """
        if summary.kubernetes is None:
            return ""

        k0s_daemon_config = summary.kubernetes.output_k0sworker_config or summary.kubernetes.output_k0scontroller_config
        if k0s_daemon_config is None:
            return ""

        # Find the line: ExecStart=/usr/local/bin/k0s worker ...
        for config_line in k0s_daemon_config.split("\n"):
            config_line = config_line.strip()
            if not config_line.startswith("ExecStart"):
                continue
            if "--cri-socket" in config_line and "/var/run/docker.sock" in config_line:
                return "docker"

        return "containerd"

    @classmethod
    def analyze(cls, collector_summary: CollectorSummary, options: FlareOptions) -> str:
        buffer = StringIO()

        def _say(*args, **kwargs):
            print(*args, **kwargs, file=buffer)

        k0s_runtime = cls._get_k0s_runtime(collector_summary)
        if k0s_runtime == "":
            _say("This system does not seem to have K0s worker configured.")
            _say()
        else:
            _say(f"K0s worker runtime: {k0s_runtime}")
            _say()

        def _check_k0s_nvidia_config():
            # Assure that we need NVIDIA at all
            try:  # type assertion
                assert k0s_runtime != ""
                assert collector_summary.system is not None
                assert collector_summary.system.output_lspci is not None
                assert "nvidia" in collector_summary.system.output_lspci.lower()
            except AssertionError:
                return

            if k0s_runtime == "containerd":
                try:  # type assertion
                    assert collector_summary.kubernetes is not None
                    assert collector_summary.kubernetes.content_k0s_containerd is not None
                except AssertionError:
                    return
                k0s_containerd_config_toml = collector_summary.kubernetes.content_k0s_containerd
                if "nvidia" not in k0s_containerd_config_toml:
                    _say("##### NVIDIA config not present in k0s containerd config!")
                    _say()
                    _say("This system uses k0s, and uses containerd as CRI.")
                    _say("In order to use NVIDIA devices in Kubernetes containers,")
                    _say("you need to add configuration at: /etc/k0s/containerd.toml")
                    _say()
                    _say("Cf. => https://docs.k0sproject.io/v1.25.16+k0s.0/runtime/#using-nvidia-container-runtime")
                    _say()
                    _say("NOTE: this is different from /etc/containerd/config.toml;")
                    _say("k0s launches its own containerd.")
                    _say()
                else:
                    _say("NVIDIA settings are present in `/etc/k0s/containerd.toml`.")

            elif k0s_runtime == "docker":
                try:  # type assertion
                    assert collector_summary.kubernetes is not None
                    assert collector_summary.kubernetes.content_docker_daemon_config is not None
                except AssertionError:
                    return
                docker_daemon_json = collector_summary.kubernetes.content_docker_daemon_config
                if "nvidia" not in docker_daemon_json:
                    _say("##### NVIDIA config not present in Docker config!")
                    _say()
                    _say("This system uses k0s, and uses Docker as CRI.")
                    _say("In order to use NVIDIA devices in Kubernetes containers,")
                    _say("you need to add configuration at: /etc/docker/daemon.json")
                    _say()
                    _say(
                        "Cf. => https://docs.nvidia.com/datacenter/cloud-native/container-toolkit/latest/install-guide.html"
                    )
                    _say()
                    _say("You might do this automatically via:")
                    _say()
                    _say("$ sudo nvidia-ctk runtime configure --runtime=docker")
                    _say("$ sudo systemctl restart docker")
                    _say()
                else:
                    _say("NVIDIA settings are present in `/etc/docker/daemon.json`.")

        _check_k0s_nvidia_config()

        return buffer.getvalue()


class DpkgAnalyzer(AbstractAnalyzer):
    @classmethod
    def analyze(cls, collector_summary: CollectorSummary, options: FlareOptions) -> str:
        buffer = StringIO()

        def _say(*args, **kwargs):
            print(*args, **kwargs, file=buffer)

        try:
            assert collector_summary.package is not None
            assert collector_summary.package.output_dpkg_l is not None
        except AssertionError:
            return "dpkg (apt) not found."

        broken_packages: List[Tuple[str, str]] = []

        for pkg_line in collector_summary.package.output_dpkg_l.split("\n"):
            m = re.match(r"^(?P<flag>[uirph][A-Za-z][ R])\s*(?P<package_name>[^\s]+)\s+(?P<version>[^\s]+)", pkg_line)
            if m is None:
                continue
            flag, package_name, version = m.group("flag"), m.group("package_name"), m.group("version")

            if flag[1] in string.ascii_uppercase or flag[2] == "R":
                broken_packages.append((package_name, version))

        if len(broken_packages) != 0:
            _say("##### Broken package!")
            _say()
            _say("It seems, from `dpkg -l`, that some packages have been broken:")
            _say()
            for package_name, version in broken_packages:
                _say(f"  - {package_name} (version: {version})")
            _say()
            _say("Please take a look. It might be fixed with:")
            _say()
            _say("$ sudo apt install --fix-broken")
        else:
            _say("dpkg status clean (no broken packages)")

        return buffer.getvalue()


class_based_analyzer_map: Dict[str, Type[AbstractAnalyzer]] = {
    "nvidia_driver": NVIDIADriverAnalyzer,
    "nvidia_gpu_check": NVIDIAGPUCheckAnalyzer,
    "k0s_config": K0sConfigAnalyzer,
    "dpkg": DpkgAnalyzer,
}


def analyze_all(collector_summary: CollectorSummary, options: FlareOptions) -> AnalyzerSummary:
    summary = AnalyzerSummary()

    for key, analyzer in class_based_analyzer_map.items():
        assert hasattr(summary, key), f"Summary should contain key '{key}'"
        setattr(summary, key, analyzer.analyze(collector_summary=collector_summary, options=options))

    return summary


def analyzer_summary_to_str(summary: AnalyzerSummary) -> Dict[str, str]:
    ret: Dict[str, str] = {}

    for key in class_based_analyzer_map:
        assert hasattr(summary, key), f"Summary should contain key '{key}'"
        result = getattr(summary, key)
        if result is not None:
            ret[key] = result

    return ret
