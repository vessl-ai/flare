"""
Standalone (i.e. with no external dependencies) HTTP interface.
"""

from http.client import HTTPResponse
from typing import IO, Tuple
from urllib.error import HTTPError
from urllib.request import Request, urlopen


def http_get(url: str) -> Tuple[str, int]:
    try:
        response: HTTPResponse = urlopen(url=url)
    except HTTPError as e:
        return e.reason, e.code

    response_body_bytes = response.read()
    response_body = response_body_bytes.decode("utf-8")

    return response_body, response.status


def http_post(url: str) -> Tuple[str, int]:
    try:
        request = Request(url=url, method="POST")
        response: HTTPResponse = urlopen(request)
    except HTTPError as e:
        return e.reason, e.code

    response_body_bytes = response.read()
    response_body = response_body_bytes.decode("utf-8")

    return response_body, response.status


def http_put_file(url: str, file: IO) -> Tuple[str, int]:
    try:
        upload_body = file.read()
        if isinstance(upload_body, str):
            upload_body = upload_body.encode("utf-8")

        request = Request(url=url, data=upload_body, method="PUT")
        response: HTTPResponse = urlopen(request)

        response_body_bytes = response.read()
        response_body = response_body_bytes.decode("utf-8")

        return response_body, response.status
    except HTTPError as e:
        return e.reason, e.code
