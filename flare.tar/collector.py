"""
Collectors that collects data from the system.
"""

import base64
import binascii
import gzip
import json
import re
from typing import Any, ClassVar, Dict, List, Optional, Tuple, Type

from classes.collector import (
    AbstractCollector,
    CollectorResult,
    CollectorResultHelm,
    CollectorResultKubernetes,
    CollectorResultNetwork,
    CollectorResultNVIDIA,
    CollectorResultPackage,
    CollectorResultSystem,
    CollectorSummary,
)
from classes.option import FlareOptions
from subproc import launch_external_command, read_file
from util import platform_switch


class CommandAndFileCollector(AbstractCollector):
    """
    Base class for collectors that:
    - run commands and takes their output, and
    - read files and take their content.

    This class can be inherited with custom `commands` and `files` to
    easily add a new collector.

    The class variable `commands` should be a list of:
        (command_id, [cmd, arg1, arg2, ...])

    The class variable `files` should be a list of:
        (file_id, path_to_file)

    `command_id` and `file_id` is used in standard output, JSON key, etc.

    `ResultType` should be a class (in classes/collector.py), and should meet
    the following requirements:
    - For each `command_id` in `commands`, there should be a field
      `output_{command_id}` in ResultType.
    - For each `file_id` in `files`, there should be a field
      `content_{command_id}` in ResultType.
    """

    commands: ClassVar[List[Tuple[str, List[str]]]] = []
    files: ClassVar[List[Tuple[str, str]]] = []
    ResultType: ClassVar[Optional[Type[CollectorResult]]] = None

    @staticmethod
    def _attr_name_command(command_id: str) -> str:
        return f"output_{command_id}"

    @classmethod
    def _get_command_output_from_result(cls, command_id: str, result: CollectorResult) -> Optional[str]:
        attr = cls._attr_name_command(command_id)
        if not hasattr(result, attr):
            raise NotImplementedError(f"Type {cls.ResultType} does not have attribute {attr}")
        return getattr(result, attr, None)

    @classmethod
    def _set_command_output_to_result(cls, command_id: str, output: str, result: CollectorResult):
        attr = cls._attr_name_command(command_id)
        if not hasattr(result, attr):
            raise NotImplementedError(f"Type {cls.ResultType} does not have attribute {attr}")
        setattr(result, attr, output)

    @staticmethod
    def _attr_name_file(file_id: str) -> str:
        return f"content_{file_id}"

    @classmethod
    def _get_file_content_from_result(cls, file_id: str, result: CollectorResult) -> Optional[str]:
        attr = cls._attr_name_file(file_id)
        if not hasattr(result, attr):
            raise NotImplementedError(f"Type {cls.ResultType} does not have attribute {attr}")
        return getattr(result, attr, None)

    @classmethod
    def _set_file_content_to_result(cls, file_id: str, content: str, result: CollectorResult):
        attr = cls._attr_name_file(file_id)
        if not hasattr(result, attr):
            raise NotImplementedError(f"Type {cls.ResultType} does not have attribute {attr}")
        setattr(result, attr, content)

    @classmethod
    def collect(cls, options: FlareOptions) -> Any:
        if cls.ResultType is None:
            raise NotImplementedError

        result = cls.ResultType()

        for command_id, command_args in cls.commands:
            output = launch_external_command(command_args, options=options)
            cls._set_command_output_to_result(command_id, output, result)

        for file_id, file_path in cls.files:
            content = read_file(file_path, options=options)
            cls._set_file_content_to_result(file_id, content, result)

        return result

    @classmethod
    def result_to_str(cls, result: CollectorResult) -> str:
        if cls.ResultType is None:
            raise NotImplementedError
        if not isinstance(result, cls.ResultType):
            raise TypeError(f"Result object {result} is not an instance of {cls.ResultType}")
        output_texts: List[str] = []

        for command_id, command_args in cls.commands:
            output = cls._get_command_output_from_result(command_id, result)
            if not output:
                continue
            output_texts.append(f"Output of `{' '.join(command_args)}`:")
            output_texts.append(output + "\n")

        for file_id, file_path in cls.files:
            content = cls._get_file_content_from_result(file_id, result)
            if not content:
                continue
            output_texts.append(f"Content of {file_path}:")
            output_texts.append(content + "\n")

        return "\n".join(output_texts)

    @classmethod
    def result_to_obj(cls, result: CollectorResult) -> dict:
        if cls.ResultType is None:
            raise NotImplementedError
        if not isinstance(result, cls.ResultType):
            raise TypeError(f"Result object {result} is not an instance of {cls.ResultType}")

        output_obj: Dict[str, Any] = {}

        if cls.commands:
            output_obj_commands = {}
            for command_id, command_args in cls.commands:
                output = cls._get_command_output_from_result(command_id, result)
                if not output:
                    continue
                output_obj_commands[command_id] = {"args": command_args, "output": output}
            output_obj["commands"] = output_obj_commands

        if cls.files:
            output_obj_files = {}
            for file_id, file_path in cls.files:
                content = cls._get_file_content_from_result(file_id, result)
                if not content:
                    continue
                output_obj_files[file_id] = {"path": file_path, "content": content}
            output_obj["files"] = output_obj_files

        return output_obj


class SystemCollector(CommandAndFileCollector):
    commands: ClassVar = [
        ("df_h", ["df", "-h"]),
        ("lsblk", ["lsblk"]),
        ("uname_a", ["uname", "-a"]),
        ("lsmod", ["lsmod"]),
        ("last", ["last"]),
        ("kernels", ["ls", "/lib/modules"]),
        ("lspci", ["lspci"]),
        ("dmesg", ["dmesg", "-T"]),
    ]
    ResultType = CollectorResultSystem


class NetworkCollector(CommandAndFileCollector):
    commands: ClassVar = [
        ("ufw_status", ["ufw", "status", "verbose"]),
        ("ip_addr", ["ip", "addr"]),
        ("ifconfig", ["ifconfig"]),
        ("iptables", ["iptables", "-L"]),
        (
            "ping_8888",
            [
                "ping",
                "-n",  # do not reverse-DNS
                "-i",  # ping interval
                "0.5",
                "-W",  # max wait
                platform_switch(linux="1", mac="1000"),
                "-c",  # count
                "4",
                "8.8.8.8",
            ],
        ),
        ("curl_example_com", ["curl", "-i", "http://example.com"]),
    ]
    files: ClassVar = [
        ("hosts", "/etc/hosts"),
        ("resolvconf", "/etc/resolv.conf"),
    ]
    ResultType = CollectorResultNetwork


class KubernetesCollector(CommandAndFileCollector):
    commands: ClassVar = [
        ("all_pods", ["k0s", "kubectl", "get", "pods", "-A"]),
        ("syslog_k0s", ["journalctl", "-x", "-t", "k0s", "-n", "100"]),
        ("k0s_status", ["k0s", "status"]),
        ("k0s_version", ["k0s", "version"]),
        ("k0sworker_config", ["systemctl", "cat", "k0sworker.service"]),
    ]
    files: ClassVar = [
        ("docker_daemon_config", "/etc/docker/daemon.json"),
        ("k0s_config_opt", "/opt/vessl/k0s/k0s.yaml"),
        ("k0s_config_etc", "/etc/k0s/k0s.yaml"),
        ("k0s_containerd", "/etc/k0s/containerd.toml"),
    ]
    ResultType = CollectorResultKubernetes


class NVIDIACollector(CommandAndFileCollector):
    commands: ClassVar = [
        ("smi_q", ["nvidia-smi", "-q"]),
        (
            "kernels_with_nvidia",
            [
                "bash",
                "-c",
                r"find /lib/modules | grep -E '/nvidia.ko$'",
            ],
        ),
    ]
    files: ClassVar = [
        ("kernel_driver_version_nvidia", "/sys/module/nvidia/version"),
        ("kernel_driver_version_nvidia_drm", "/sys/module/nvidia_drm/version"),
        ("kernel_driver_version_nvidia_uvm", "/sys/module/nvidia_uvm/version"),
        ("kernel_driver_version_nvidia_modeset", "/sys/module/nvidia_modeset/version"),
        ("nvidia_container_runtime_config", "/etc/nvidia-container-runtime/config.toml"),
        ("k0s_containerd_config", "/etc/k0s/containerd.toml"),
    ]
    ResultType = CollectorResultNVIDIA


class PackageCollector(CommandAndFileCollector):
    commands: ClassVar = [
        ("dpkg_l", ["dpkg", "-l"]),
        ("yum_list_installed", ["yum", "list", "installed"]),
    ]
    files: ClassVar = [("apt_unattended_upgrades", "/var/log/unattended-upgrades/unattended-upgrades.log")]
    ResultType = CollectorResultPackage


class HelmCollector(AbstractCollector):
    @staticmethod
    def _get_k8s_secret_names(options: FlareOptions) -> List[str]:
        return (
            launch_external_command(
                [
                    "k0s",
                    "kubectl",
                    "get",
                    "secret",
                    "-A",
                    "--template",
                    r'{{range .items}}{{.metadata.namespace}}/{{.metadata.name}}{{"\n"}}{{end}}',
                ],
                options=options,
            )
            .strip()
            .split("\n")
        )

    @classmethod
    def _get_helm_release_names(cls, options: FlareOptions) -> List[Tuple[str, str]]:
        # list secrets
        secret_list = cls._get_k8s_secret_names(options)

        helm_release_names: List[Tuple[str, str]] = []

        for secret in secret_list:
            m = re.match(r"^(?P<namespace>[0-9a-z-_]+)/(?P<name>[0-9a-z-_.]+)$", secret)
            if m is None:
                continue
            namespace, name = m.group("namespace"), m.group("name")
            if not name.startswith("sh.helm.release.v1"):
                continue
            helm_release_names.append((namespace, name))

        return helm_release_names

    @classmethod
    def collect(cls, options: FlareOptions) -> Any:
        result = CollectorResultHelm()
        result.releases = []

        release_names = cls._get_helm_release_names(options=options)
        for namespace, name in release_names:
            k8s_secret_str = launch_external_command(
                ["k0s", "kubectl", "get", "secret", "-o", "json", "-n", namespace, name], options=options
            )
            try:
                k8s_secret_obj = json.loads(k8s_secret_str)
            except json.JSONDecodeError:
                continue

            try:
                release_str = k8s_secret_obj["data"]["release"]
                release_str_decode = base64.b64decode(release_str, validate=True).decode("utf-8")
                release_str_decode2 = base64.b64decode(release_str_decode, validate=True)
                release_str_decode3 = gzip.decompress(release_str_decode2).decode("utf-8")
                release_obj = json.loads(release_str_decode3)
                assert isinstance(release_obj, dict)
            except (KeyError, json.JSONDecodeError, binascii.Error, UnicodeDecodeError):
                continue

            release = CollectorResultHelm.HelmRelease()
            release.secret_namespace = namespace
            release.secret_name = name
            release.release_obj = release_obj
            release.values = release_obj.get("config", {})

            result.releases.append(release)

        return result

    @classmethod
    def result_to_str(cls, result: CollectorResult) -> str:
        if not isinstance(result, CollectorResultHelm):
            raise TypeError(f"Result object {result} is not an instance of {CollectorResultHelm}")

        if result.releases is None or len(result.releases) == 0:
            return "(no Helm release found)"

        result_strs: List[str] = []

        for release in result.releases:
            chart_version_info = "(unknown Helm release; has no metadata)"
            try:
                assert release.release_obj is not None
                chart_metadata: dict = release.release_obj["chart"]["metadata"]
                chart_name = chart_metadata.get("name", "(unknown name)")
                chart_version = chart_metadata.get("version", "(unknown version)")
                chart_app_version = chart_metadata.get("appVersion", "(unknown app version)")
                chart_version_info = f"{chart_name}: version {chart_version} (app version: {chart_app_version})"
            except (AssertionError, KeyError):
                pass
            result_strs.append(chart_version_info)

            result_strs.append(f"(Kubernetes Secret: {release.secret_namespace}/{release.secret_name})")

            result_strs.append("Values:")
            if release.values:
                result_strs.append(json.dumps(release.values, indent=2))
            else:
                result_strs.append("(Not found)")

            result_strs.append("")

        return "\n".join(result_strs)

    @classmethod
    def result_to_obj(cls, result: CollectorResult) -> dict:
        if not isinstance(result, CollectorResultHelm):
            raise TypeError(f"Result object {result} is not an instance of {CollectorResultHelm}")

        result_obj: Dict[str, Any] = {}

        if result.releases is not None and len(result.releases) != 0:
            release_objs = []
            for release in result.releases:
                obj: Dict[str, Any] = {}
                obj["k8s_secret_name"] = f"{release.secret_namespace}/{release.secret_name}"
                obj["release_obj"] = release.release_obj
                obj["values"] = release.values
                release_objs.append(obj)
            result_obj["releases"] = release_objs

        return result_obj


class_based_collector_map: Dict[str, Type[AbstractCollector]] = {
    "system": SystemCollector,
    "network": NetworkCollector,
    "kubernetes": KubernetesCollector,
    "nvidia": NVIDIACollector,
    "package": PackageCollector,
    "helm": HelmCollector,
}


def collect_all(options: FlareOptions) -> CollectorSummary:
    summary = CollectorSummary()

    for key, collector_class in class_based_collector_map.items():
        assert hasattr(summary, key), f"Summary should contain key '{key}'"
        setattr(summary, key, collector_class.collect(options))

    return summary


def collector_summary_to_str(summary: CollectorSummary) -> Dict[str, str]:
    ret: Dict[str, str] = {}

    for key, collector_class in class_based_collector_map.items():
        assert hasattr(summary, key), f"Summary should contain key '{key}'"
        result = getattr(summary, key)
        if result is not None:
            ret[key] = collector_class.result_to_str(result)

    return ret


def collector_summary_to_obj(summary: CollectorSummary) -> Dict[str, Any]:
    ret: Dict[str, Any] = {}

    for key, collector_class in class_based_collector_map.items():
        assert hasattr(summary, key), f"Summary should contain key '{key}'"
        result = getattr(summary, key)
        if result is not None:
            ret[key] = collector_class.result_to_obj(result)

    return ret
