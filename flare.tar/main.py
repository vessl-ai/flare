#!/usr/bin/env python
"""
Entrypoint for VESSL Flare.
"""

import analyzer
import collector
import option
import output


def f(x: int):
    print("hi")


def main():
    options = option.parse_args()
    option.init_logger(options=options)

    collector_summary = collector.collect_all(options=options)

    analyzer_summary = analyzer.analyze_all(collector_summary=collector_summary, options=options)

    output.output_to_stdout(collector_summary=collector_summary, analyzer_summary=analyzer_summary, options=options)

    if options.create_tarball:
        tarball_path = output.output_to_tarball(
            collector_summary=collector_summary, analyzer_summary=analyzer_summary, options=options
        )
        print(f"Created tarball to: {tarball_path}")
        print()

        if options.send_tarball_to_vessl:
            output.output_to_flare_server(tarball_path=tarball_path, options=options)


if __name__ == "__main__":
    main()
