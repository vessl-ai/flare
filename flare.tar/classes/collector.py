from typing import Any, List, Optional

from .option import FlareOptions


class CollectorResult:
    """
    Abstract base class for collectors' results.
    """


class CollectorResultSystem(CollectorResult):
    output_lsblk: Optional[str] = None
    output_df_h: Optional[str] = None
    output_uname_a: Optional[str] = None
    output_lsmod: Optional[str] = None
    output_last: Optional[str] = None


class CollectorResultNetwork(CollectorResult):
    output_ufw_status: Optional[str] = None
    output_ip_addr: Optional[str] = None
    output_ifconfig: Optional[str] = None
    output_iptables: Optional[str] = None
    output_ping_8888: Optional[str] = None
    output_curl_example_com: Optional[str] = None
    content_hosts: Optional[str] = None
    content_resolvconf: Optional[str] = None


class CollectorResultKubernetes(CollectorResult):
    output_all_pods: Optional[str] = None
    output_syslog_k0s: Optional[str] = None
    output_k0s_status: Optional[str] = None
    output_k0s_version: Optional[str] = None
    content_docker_daemon_config: Optional[str] = None
    content_k0s_config_opt: Optional[str] = None
    content_k0s_config_etc: Optional[str] = None


class CollectorResultNVIDIA(CollectorResult):
    output_smi_q: Optional[str] = None

    content_kernel_driver_version_nvidia: Optional[str] = None
    content_kernel_driver_version_nvidia_drm: Optional[str] = None
    content_kernel_driver_version_nvidia_uvm: Optional[str] = None
    content_kernel_driver_version_nvidia_modeset: Optional[str] = None
    content_nvidia_container_runtime_config: Optional[str] = None
    content_k0s_containerd_config: Optional[str] = None


class CollectorResultPackage(CollectorResult):
    output_dpkg_l: Optional[str] = None
    output_yum_list_installed: Optional[str] = None
    content_apt_unattended_upgrades: Optional[str] = None


class CollectorResultHelm(CollectorResult):
    class HelmRelease:
        secret_namespace: Optional[str] = None
        secret_name: Optional[str] = None
        release_obj: Optional[dict] = None
        values: Optional[dict] = None

    releases: Optional[List[HelmRelease]] = None


class CollectorSummary:
    """
    Class that holds all collector results.
    """

    system: Optional[CollectorResultSystem] = None
    network: Optional[CollectorResultNetwork] = None
    kubernetes: Optional[CollectorResultKubernetes] = None
    nvidia: Optional[CollectorResultNVIDIA] = None
    package: Optional[CollectorResultPackage] = None
    helm: Optional[CollectorResultHelm] = None


class AbstractCollector:
    """
    Abstract base class for collectors.
    """

    @classmethod
    def collect(cls, options: FlareOptions) -> Any:
        raise NotImplementedError()

    @classmethod
    def result_to_str(cls, result: CollectorResult) -> str:
        raise NotImplementedError()

    @classmethod
    def result_to_obj(cls, result: CollectorResult) -> dict:
        raise NotImplementedError()
