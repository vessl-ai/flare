from typing import Optional

from classes.collector import CollectorSummary
from classes.option import FlareOptions


class AnalyzerSummary:
    """
    Class that holds all analyzer results.
    """

    nvidia_driver: Optional[str] = None
    nvidia_gpu_check: Optional[str] = None
    k0s_config: Optional[str] = None
    dpkg: Optional[str] = None


class AbstractAnalyzer:
    """
    Abstract base class for analyzers.
    """

    @classmethod
    def analyze(cls, collector_summary: CollectorSummary, options: FlareOptions) -> str:
        raise NotImplementedError()
