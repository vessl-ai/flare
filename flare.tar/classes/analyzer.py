class AnalyzerResult:
    """
    Abstract base class for analyzers' results.
    """


class AnalyzerSummary:
    """
    Class that holds all analyzer results.
    """
