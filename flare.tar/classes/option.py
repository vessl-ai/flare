class FlareOptions:
    """
    Options on invoking flare.
    """

    log_level: int
    create_tarball: bool
    send_tarball_to_vessl: bool

    def __init__(self):
        self.log_level = 0
        self.create_tarball = False
        self.send_tarball_to_vessl = False
