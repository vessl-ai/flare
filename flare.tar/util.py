def decode_or_base64(b: bytes) -> str:
    try:
        s = b.decode("utf-8")
        return s
    except UnicodeError:
        pass

    # Maybe while taking last N bytes, a codepoint was cut in the middle?
    # (e.g. U+D55C = 0xED 0x95 0x9C, and taking b'\xED\x95\x9C....'[:-5000]
    # yields b'\x95\x9C...', which is invalid in UTF-8)
    # Try decoding with a few bytes ahead.
    if len(b) >= 10:
        for offset in range(1, 10):
            try:
                s = b[offset:].decode("utf-8", errors="strict")
                return s
            except UnicodeError:
                pass

    import base64

    return base64.standard_b64encode(b).decode("ascii")


def file_size_pretty(size_in_bytes: int) -> str:
    if size_in_bytes < 1024:
        return f"{size_in_bytes} bytes"

    units = ["bytes", "KiB", "MiB"]
    size_number = float(size_in_bytes)

    while size_number >= 1024 and len(units) >= 2:
        size_number /= 1024
        units = units[1:]

    return f"{size_number:.2f} {units[0]}"


def platform_switch(linux: str = "", mac: str = "", windows: str = "", default: str = "") -> str:
    import sys

    if sys.platform.startswith("linux"):
        return linux
    if sys.platform.startswith("darwin"):
        return mac
    if sys.platform.startswith("win32") or sys.platform.startswith("cygwin"):
        return windows
    return default
