"""
Options (provided on argv) to tweak Flare's behavior.
"""

import argparse
import logging

from classes.option import FlareOptions


def parse_args() -> FlareOptions:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--log-level",
        choices=["DEBUG", "INFO", "WARN", "ERROR"],
        default="INFO",
        type=lambda s: getattr(logging, s),
        help="Configure the logging level.",
    )
    parser.add_argument(
        "--no-tarball",
        dest="tarball",
        action="store_false",
        help="If specified, do not create a tarball. This implies --no-send.",
    )
    parser.add_argument(
        "--no-send", dest="send", action="store_false", help="If specified, do not send the tarball to VESSL."
    )

    args = parser.parse_args()

    options = FlareOptions()
    options.log_level = args.log_level
    options.create_tarball = args.tarball
    options.send_tarball_to_vessl = args.tarball and args.send

    return options


def init_logger(options: FlareOptions):
    logging.basicConfig(level=options.log_level)
