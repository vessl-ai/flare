import logging
import os
import subprocess
from typing import List, Optional

import util
from classes.option import FlareOptions

_has_sudo = None


def launch_external_command(
    args: List[str],
    options: FlareOptions,
    *,
    timeout_seconds: float = 10,
    max_bytes: Optional[int] = None,
) -> str:
    """
    Execute given command, and return its output.

    It parses UTF-8 string outputs properly, and if the output is binary or not valid in UTF-8,
    it returns Base64-encoded form of the output.
    """

    args_joined = " ".join(args)  # for logging

    try:
        process: subprocess.CompletedProcess = subprocess.run(
            args=args,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=timeout_seconds,
        )
    except Exception as e:
        logging.warning(f"Command '{args_joined}' failed: {e}")
        logging.debug("Exception:", exc_info=e)
        return str(e)

    if process.returncode != 0:
        logging.warning(f"Command '{args_joined}' exited in code {process.returncode}.")

    output_bytes = process.stdout
    if max_bytes is not None:
        # Take last `max_bytes` bytes.
        output_bytes = output_bytes[-max_bytes:]

    output_str = util.decode_or_base64(output_bytes)
    return output_str


def read_file(
    file_path: str,
    options: FlareOptions,
    *,
    max_bytes: Optional[int] = None,
) -> str:
    """
    Read a file and return its output.

    It parses UTF-8 string outputs properly, and if the output is binary or not valid in UTF-8,
    it returns Base64-encoded form of the output.
    """

    try:
        stat = os.stat(file_path)
    except FileNotFoundError as e:
        logging.warning(f"File {file_path} does not exist")
        return str(e)

    file_size = stat.st_size

    try:
        f = open(file=file_path, mode="rb")
        if max_bytes is not None and file_size > max_bytes:
            f.seek(file_size - max_bytes, os.SEEK_CUR)

        content_bytes = f.read()
    except Exception as e:
        logging.warning(f"Error reading file {file_path}: {e}")
        return str(e)

    content_str = util.decode_or_base64(content_bytes)
    return content_str
