"""
Implementation of outputting summaries to tarball, network, etc.
"""

import io
import json
import logging
import os
import tarfile
from pathlib import Path
from tempfile import NamedTemporaryFile
from typing import Dict, Optional

import analyzer
import collector
import const
from analyzer import AnalyzerSummary
from collector import CollectorSummary
from network import http_post, http_put_file
from option import FlareOptions
from util import file_size_pretty


def output_to_stdout(collector_summary: CollectorSummary, analyzer_summary: AnalyzerSummary, options: FlareOptions):
    d_coll = collector.collector_summary_to_str(collector_summary)
    for key, value in d_coll.items():
        print(f"{key}:")
        print(value)

    print("COLLECTED INFORMATION END")
    print()
    print("================================")
    print()
    print("ANALYSIS")

    d_anal = analyzer.analyzer_summary_to_str(analyzer_summary)
    for key, value in d_anal.items():
        print(f"{key}:")
        print(value)

    print()


def output_to_tarball(
    collector_summary: CollectorSummary, analyzer_summary: AnalyzerSummary, options: FlareOptions
) -> Path:
    d_coll = collector.collector_summary_to_obj(collector_summary)
    d_anal = analyzer.analyzer_summary_to_str(analyzer_summary)

    tarball_file_obj = NamedTemporaryFile(suffix=".tar", delete=False)

    with tarfile.open(mode="w", fileobj=tarball_file_obj) as tarball:
        for key, obj in d_coll.items():
            filename_in_tarball = f"collector-{key}.json"
            json_bytes = json.dumps(obj).encode("ascii")

            tarinfo = tarfile.TarInfo(name=filename_in_tarball)
            tarinfo.size = len(json_bytes)
            tarball.addfile(tarinfo, io.BytesIO(json_bytes))

        for key, txt in d_anal.items():
            filename_in_tarball = f"analyzer-{key}.txt"
            txt_bytes = txt.encode("utf-8")

            tarinfo = tarfile.TarInfo(name=filename_in_tarball)
            tarinfo.size = len(txt_bytes)
            tarball.addfile(tarinfo, io.BytesIO(txt_bytes))

    return Path(tarball_file_obj.name)


def _get_uploadable_info(options: FlareOptions) -> Optional[Dict[str, str]]:
    url_issue_endpoint = const.user_upload_url_issue_endpoint
    resp, code = http_post(url=url_issue_endpoint)
    if code != 200:
        logging.error(f"HTTP error on asking for an upload URL. Status code: {code}, reason: {resp}")
        logging.debug(f"URL: {url_issue_endpoint}")
        return None

    try:
        uploadable_info: Dict[str, str] = json.loads(resp)
    except json.JSONDecodeError:
        logging.error(f"Invalid JSON: {resp}")
        return None

    try:
        assert "url" in uploadable_info
        assert "key" in uploadable_info
    except AssertionError:
        logging.error("Upload information does not contain required keys.")
        return None

    return uploadable_info


def output_to_flare_server(tarball_path: Path, options: FlareOptions):
    print("Flare will now upload the output to VESSL.")
    print()
    print("Retrieving upload information...")
    uploadable_info = _get_uploadable_info(options=options)
    if uploadable_info is None:
        print("*** OUTPUT UPLOAD FAILED!")
        print("An error occurred while retrieving upload information.")
        print("Please try again later.")
        return

    upload_url = uploadable_info["url"]
    upload_key = uploadable_info["key"]

    file_size_str = file_size_pretty(os.stat(tarball_path).st_size)
    print("Flare is now ready to upload the output.")
    print(f"- Key: {upload_key}")
    print(f"- File size: {file_size_str}")
    print()

    print("Uploading...")
    resp, code = http_put_file(url=upload_url, file=open(file=tarball_path, mode="rb"))
    if not (200 <= code and code <= 299):
        logging.error(f"HTTP error while uploading. Status code: {code}, reason: {resp}")
        print("*** OUTPUT UPLOAD FAILED!")
        print("An error occurred while uploading output.")
        print("Please try again later.")
        return

    print("Successfully uploaded Flare output!")
    print()
    print("Please provide the following information to VESSL Support:")
    print()
    print(f"    - Flare key: {upload_key}")
    print()
    print("E-mail: VESSL Support <support@vessl.ai>")
    print()
